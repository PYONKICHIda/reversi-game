# Install

```TypeScript CLI
npm install -g typescript
```

```React Project
npm create vite@latest my-react-app  -- --template react-ts
npm create vite@latest my-react-app  -- --template react-swc-ts
```
