const a: string = 'Hello';
console.log(a)