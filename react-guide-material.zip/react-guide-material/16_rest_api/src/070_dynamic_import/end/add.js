export const add = (a, b) => a + b; 
export default 3;