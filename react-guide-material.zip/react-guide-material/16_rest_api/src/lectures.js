/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  '020_what_is_json',
  '030_json_server',
  '040_axios_get_request',
  '050_axios_get_state',
  '060_other_method',
  '070_dynamic_import',
  '080_react_lazy',
];

export default lectures;
