const Example = () => {
  return (
    <>
    <h3>再レンダリングが発生する条件</h3>
    <p>stateの値が変更された時</p>
    <p>Object.isによって変更は検知される</p>
    </>
  );
};

export default Example;
