const Example = () => {
  return (
    <h3>React.memoで子コンポーネントの再レンダリングを防止</h3>
  );
};

export default Example;
