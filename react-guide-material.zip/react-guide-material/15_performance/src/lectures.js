/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_Objectis",
  "012_strictmode",
  "015_child_rerender",
  "020_memo",
  "030_useCallback",
  "040_useCallback_deps",
  "050_useMemo",
  "055_practice_re-rendering",
  "060_useTransition",
  "070_useDeferredValue",
];

export default lectures;
