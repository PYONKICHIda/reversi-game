const Example = () => {
  return (
    <>
    <h3>再レンダリング</h3>
    <p>親コンポーネントが再レンダリングされると子コンポーネントも再レンダリングされる</p>
    <p>コンソールを要確認</p>
    </>
  );
};

export default Example;
