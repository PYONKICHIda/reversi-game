/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_check_error",
  "020_debugging",
  "030_devtool_reminder",
];

export default lectures;
