import CounterReducer from "./components/CounterReducer";

const Example = () => {
  const originCount = 0;

  return <CounterReducer originCount={originCount}></CounterReducer>;
};

export default Example;
