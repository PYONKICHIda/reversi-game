/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  '010_first_test_run',
  '020_get_element',
  '030_how_to_test',
  '040_test_suite',
  '045_pure_fn_test',
  '050_userEvent',
  '055_practice_userEvent',
  '060_async_test',
  '070_function_mock',
];

export default lectures;
