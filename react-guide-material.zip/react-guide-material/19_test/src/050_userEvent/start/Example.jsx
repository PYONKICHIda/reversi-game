import Message from "./components/Message";

const Example = () => {
  return (
    <>
      <Message></Message>
    </>
  );
};

export default Example;
