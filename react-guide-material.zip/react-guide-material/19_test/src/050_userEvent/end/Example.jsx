
import Message from "./components/Message";

const Example = () => {
  return (
    <>
      <Message />
    </>
  );
};

export default Example;
