import Greet from "./components/Greet";

const Example = () => {
  return <Greet />;
};

export default Example;
