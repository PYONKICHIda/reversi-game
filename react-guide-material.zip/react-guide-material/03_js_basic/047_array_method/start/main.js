const arry = [10, 20, 30, 40];
const newArry = [];