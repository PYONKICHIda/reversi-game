/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_eventlistener",
  "015_other_events",
  "020_useState",
  "030_useState_render",
  "040_multiple_state",
  "050_prev_state",
  "055_practice_state",
  "060_state_object",
  "064_state_array",
  "068_practice_obj_state",
  "070_state_and_component",
  "080_state_and_props",
  "090_practice_state_props",
];

export default lectures;
