import { Component } from "react";

class Example extends Component {
  render() {
    return (
      <h3>I'm Class Component</h3>
    );
  }
}

export default Example;
