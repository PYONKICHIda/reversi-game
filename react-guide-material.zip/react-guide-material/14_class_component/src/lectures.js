/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_introduce",
  "020_react_class_comp",
  "030_state",
  "040_lifecycle",
  "050_error_boundary",
];

export default lectures;
