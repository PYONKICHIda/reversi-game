const Example = () => {
  return (
    <h3>I'm Function Component</h3>
  );
};

export default Example;
