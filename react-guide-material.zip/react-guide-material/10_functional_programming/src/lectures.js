/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_data_procedure",
  "020_pure_function",
  "030_immutability",
  "040_react_pure_fn",
  "050_react_data_procedure",
  "060_react_immutability",
  "070_js_vs_react",
];

export default lectures;
