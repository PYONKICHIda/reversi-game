import Todo from "./components/Todo"

// POINT React vs JS Todo App
const Example = () => {
  return (
    <>
      <h2>Reminder</h2>
      <Todo />
    </>
  );
};

export default Example;
