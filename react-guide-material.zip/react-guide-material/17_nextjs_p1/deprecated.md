# 注意
このコンテンツはNext.jsのバージョン12のPages Routerで作成されたものです。
最新のApp Routerの教材は**21_nextjs_app_router**フォルダになりますので注意してください。