const Example = () => {
  return (
    <div>
      <h3>endフォルダのコード</h3>
    </div>
  );
};
export default Example;
