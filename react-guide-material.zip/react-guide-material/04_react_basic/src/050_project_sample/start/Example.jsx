const Example = () => {
  return (
    <div>
      <h3>startフォルダのコード</h3>
    </div>
  );
};

export default Example;
