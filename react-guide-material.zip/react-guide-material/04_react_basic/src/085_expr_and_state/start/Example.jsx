import Child from "./components/Child";

const Example = () => <Child />;

export default Example;
