/**
 * レクチャーID（フォルダ名）を追加
 */
const lectures = [
  "010_portals",
  "020_practice_portals",
  "030_useRef",
  "040_forwardRef",
  "050_useImperativeHandle",
  "060_practice_ref",
];

export default lectures;
