export const navList = [
  "010_SSR",
  "020_SG",
  "030_SG_fetch",
  "040_api_routes",
  "050_actions",
];
