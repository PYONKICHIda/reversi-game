export default function notFound() {
    return <div>Not Found</div>
}